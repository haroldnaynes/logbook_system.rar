READ ME!!!
Logbook system is a system that able to track attendance of someone or specifically
the persons who are in schools because this logbook system is suited in school purposes
that can be use in tracking attendance.


When the system launch, it is directly go to the dashboard with 4 buttons: "add user"
"view users", "view visitors" and "timein/timeout" which corresponds with there functions.

the admin has the power to use the function of the systems.

1.The add admin will add or register the personal info of the teacher/students/visitors.
It will records the basic informations of the person who will be registered.

2. If you want to view the users or the persons who registered, just click the "View users"
button and in this form you can Edit/Update the personal info, and you can also delete the person
in the system or database.

3. If the registration is done, the admin will go to the timein/timeout and just type the School ID
of the person and just click the time in to show the date and time that the person arrived in the school.
in this feature you can also time out.

4. once you time in or time out and want to view or track the record, just click the View Viisitors. and it will
display all the record of the time in and time out.
