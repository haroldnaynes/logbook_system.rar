<?php 
include "config.php";
ini_set('display_errors', 0);
ini_set('display_errors', false);
date_default_timezone_set('Asia/Manila');
$time = date("h:i:s");
$today = date("D - F d, Y");
$date = date("Y-m-d");
$in = date("H:i:s");
$out = "12:00:00";

if (isset($_POST['time-in'])) 
{
  $_SESSION['expire'] =  date("H:i:s", time() + 1);
    $id = $_POST['visitors_id'];
    $sql = "SELECT * FROM `visitors_list` WHERE `visitors_card` = '$id'";
    $result = mysqli_query($conn, $sql);
    if(!$row = $result->fetch_assoc()) {
      $_SESSION['mess'] = "<div id='time' class='alert alert-danger' role='alert'>
                              <i class='fas fa-times'></i>  Employee ID is not registered !
                              </div>";
      //header("Location: index.php");
    }
else{
    $sql2 = "INSERT INTO `visitors_attendance`(`visitors_card`, `visitors_date`, `time_in`, `time_out`) VALUES ('$id','$date','$in','$out')";
    $result2 = $conn->query($sql2);
    if ($result2 == TRUE) {
      echo "New record created successfully.";
    }else{
      echo "Error:". $sql2 . "<br>". $conn->error;
    }
}
if (isset($_POST['time-out'])) 
{
  $_SESSION['expire'] =  date("H:i:s", time() + 1);
    $id = $_POST['visitors_id'];
    $sql = "SELECT * FROM `visitors_list` WHERE `visitors_card` = '$id'";
    $result = mysqli_query($conn, $sql);
    if(!$row = $result->fetch_assoc()) {
      $_SESSION['mess'] = "<div id='time' class='alert alert-danger' role='alert'>
                              <i class='fas fa-times'></i>  Employee ID is not registered !
                              </div>";
      //header("Location: index.php");
    }
else{
    $sql2 = "INSERT INTO `visitors_attendance`(`visitors_card`, `visitors_date`, `time_in`, `time_out`) VALUES ('$id','$date','$in','$out')";
    $result2 = $conn->query($sql2);
    if ($result2 == TRUE) {
      echo "New record created successfully.";
    }else{
      echo "Error:". $sql2 . "<br>". $conn->error;
    }
}
      $sql2 = "UPDATE emp_attendance SET attendance_timeout = '$in', attendance_hour = '$int' WHERE employee_id = '$id' AND attendance_date = '$date'";
      $result2 = mysqli_query($db, $sql2);
      $_SESSION['mess'] = "<div id='time' class='alert alert-success' role='alert'>
                            <i class='fas fa-check'></i>  Timed Out
                           </div>";
      header("Location: index.php");
    }
  }

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <p id="date"><?php echo $today; ?></p>
    <p id="time" class="bold"><?php echo $time; ?></p>
  </div>
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">
      <p class="login-box-msg">Enter ID</p>

      <form action="" method="POST">

        <div class="input-group mb-3">
          <input type="text" name="visitors_id" class="form-control" placeholder="ID">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-id-card"></span>
            </div>
          </div>
        </div>
        <br>
        <button type="submit" name="time-in">Time In</button>
        <button type="submit" name="time-out">Time Out</button>

      </form>
    </div>

    <?php
       echo $_SESSION['mess'];
    echo $_SESSION['success'];
    $dd = date("H:i:s");

    if($dd == $_SESSION['expire'])
    {
      session_unset();
    }
    ?>

  </div>
</div>
<br><br>

<script type="text/javascript">
var interval = setInterval(function() {
   var momentNow = moment();
   $('#date').html(momentNow.format('dddd').substring(0,3).toUpperCase() + ' - ' + momentNow.format('MMMM DD, YYYY'));
   $('#time').html(momentNow.format('hh:mm:ss A'));
 }, 100);
</script>


</body>
</html>