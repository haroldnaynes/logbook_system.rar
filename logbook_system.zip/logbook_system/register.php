<?php 
include "config.php";

  if (isset($_POST['submit'])) {
    // get variables from the form
    $visitors_card = $_POST['visitors_card'];
    $first_name = $_POST['firstname'];
    $last_name = $_POST['lastname'];
    $address = $_POST['address'];
    $contact_no = $_POST['contact_no'];
    $category = $_POST['category'];

    $sql = "INSERT INTO visitors_list (`visitors_card`, `fname`, `lname`, `address`, `contact_no`,`category`) 
                VALUES ('$visitors_card','$first_name','$last_name','$address','$contact_no','$category')";

    $result = $conn->query($sql);

    if ($result == TRUE) {
      echo "New record created successfully.";
    }else{
      echo "Error:". $sql . "<br>". $conn->error;
    }
  $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Registration Form In HTML and CSS</title>
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>
  
<div class="wrapper">
  <div class="registration_form">
    <div class="title">
      Registration Form
    </div>

    <form action="" method="POST">
      <div class="form_wrap">
        <div class="input_grp">
          <div class="input_wrap">
            <label for="fname">First Name</label>
            <input type="text" name="firstname" placeholder="First name" required="">
          </div>
          <div class="input_wrap">
            <label for="lname">Last Name</label>
            <input type="text" name="lastname" placeholder="Last Name" required="">
          </div>
        </div>
        <div class="input_wrap">
          <label for="school_id">School ID</label>
          <input type="text" name="visitors_card" placeholder="Enter Your School ID" required="">
        </div>
        <div class="input_wrap">
          <label for="address">Address</label>
          <input type="text" name="address" placeholder="Enter Your Address" required="">
        </div>
        <div class="input_wrap">
          <label for="contact_no">Contact Number</label>
          <input type="text" name="contact_no" placeholder="Enter Your CP Number" required="">
        </div>
        <div class="input_wrap">
          <label>Category</label>
          <ul>
            <li>
              <label class="radio_wrap">
                <input type="radio" name="category" value="Teacher" class="input_radio" required="">
                <span>Teacher</span>
              </label>
            </li>
            <li>
              <label class="radio_wrap">
                <input type="radio" name="category" value="Student" class="input_radio" required="">
                <span>Student</span>
              </label>
            </li>            
            <li>
              <label class="radio_wrap">
                <input type="radio" name="category" value="Visitor" class="input_radio" required="">
                <span>Visitor</span>
              </label>
            </li>
          </ul>
        </div>

        <div class="input_wrap">
          <input type="submit" value="Register Now" class="submit_btn" name="submit">
        </div>
      </div>
    </form>
  </div>
</div>

</body>
</html>