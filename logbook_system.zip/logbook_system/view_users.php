<?php 
include "config.php";

//write the query to get data from users table

$sql = "SELECT * FROM visitors_list";

//execute the query

$result = $conn->query($sql);


?>

<!DOCTYPE html>
<html>
<head>
	<title>View Page</title>
	 <!-- to make it looking good im using bootstrap -->
	 <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
</head>
<body>
	<div class="container">
		<h2>users</h2>
<table class="table">
	<thead>
		<tr>
		<th>School ID</th>
		<th>First Name</th>
		<th>Last Name</th>
		<th>Address</th>
		<th>Contact No.</th>
		<th>Category</th>
	</tr>
	</thead>
	<tbody>	
		<?php
			if ($result->num_rows > 0) {
				//output data of each row
				while ($row = $result->fetch_assoc()) {
		?>

					<tr>
					<td><?php echo $row['visitors_card']; ?></td>
					<td><?php echo $row['fname']; ?></td>
					<td><?php echo $row['lname']; ?></td>
					<td><?php echo $row['address']; ?></td>
					<td><?php echo $row['contact_no']; ?></td>
					<td><?php echo $row['category']; ?></td>
					
					<td><a class="btn btn-info" href="update.php?visitors_id=<?php echo $row['visitors_id']; ?>">Edit</a>&nbsp;<a class="btn btn-danger" href="delete.php?visitors_card=<?php echo $row['visitors_card']; ?>">Delete</a></td>
					</tr>	
					
		<?php		}
			}
		?>
	        	
	</tbody>
</table>
	</div>

</body>
</html>