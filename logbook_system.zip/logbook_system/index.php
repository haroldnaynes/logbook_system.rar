<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/dashboard.css">
  </head>
  <body>
<div class="container">
  <button onclick="window.location.href='Register.php';" class="btn">Add User</button>
  <button onclick="window.location.href='view_users.php';" class="btn">View Users</button>
  <button onclick="window.location.href='attendance.php';" class="btn">Timein / Timeout</button>
  <button onclick="window.location.href='view_visitors.php';" class="btn">View Visitors</button>
  

</div>
  </body>
</html>
