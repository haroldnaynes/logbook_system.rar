<?php 
include "config.php";

if(isset($_POST['username'])){
    
    $username=$_POST['username'];
    $password=$_POST['password'];
    
    $sql= "SELECT * FROM admin WHERE username ='".$username."'AND password='".$password."' limit 1";
    
    $result=mysql_query($sql);
    
    if(mysql_num_rows($result)==1){
        echo " You Have Successfully Logged in";
       header("Location: dashboard");
    }
    else{
        echo " You Have Entered Incorrect Password";
        exit();
    }
        
}

?>

<!DOCTYPE html>
<html>
<head>
    <title> Login Form in HTML5 and CSS3</title>
    <link rel="stylesheet" a href="css\admin.css">
    <link rel="stylesheet" a href="css\font-awesome.min.css">
</head>
<body>
    <div class="container">
        <form action="" method="POST">
            <div class="form-input">
                <input type="text" name="text" placeholder="Enter the User Name"/>  
            </div>
            <div class="form-input">
                <input type="password" name="password" placeholder="password"/>
            </div>
            <input type="submit" type="submit" value="LOGIN" class="btn-login"/>
        </form>
    </div>
</body>
</html>