<?php 
include "config.php";

// if the form's update button is clicked, we need to process the form
	if (isset($_POST['update'])) {
    // get variables from the form
	$visitors_id = $_POST['visitors_id'];
    $visitors_card = $_POST['visitors_card'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $address = $_POST['address'];
    $contact_no = $_POST['contact_no'];
    $category = $_POST['category'];

		// write the update query
		$sql = "UPDATE `visitors_list` SET `visitors_card`='$visitors_card', `fname`='$fname',`lname`='$lname',`address`='$address',`contact_no`='$contact_no',`category`='$category' WHERE `visitors_id`='$visitors_id'";

		// execute the query
		$result = $conn->query($sql);

		if ($result == TRUE) {
			echo "Record updated successfully.";
		}else{
			echo "Error:" . $sql . "<br>" . $conn->error;
		}
	}


// if the 'id' variable is set in the URL, we know that we need to edit a record
if (isset($_GET['visitors_id'])) {
	$visitors_id = $_GET['visitors_id'];

	// write SQL to get user data
	$sql = "SELECT * FROM `visitors_list` WHERE `visitors_id`='$visitors_id'";

	//Execute the sql
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		
		while ($row = $result->fetch_assoc()) {
			$visitors_id = $row['visitors_id'];
			$visitors_card = $row['visitors_card'];
			$fname = $row['fname'];
			$lname = $row['lname'];
			$address = $row['address'];
			$contact_no  = $row['contact_no'];
			$category = $row['category'];
			
		}

	?>
		<h2>User Update Form</h2>
		<form action="" method="post">
		  <fieldset>
		    <legend>Personal information:</legend>
		    School Card:<br>
		    <input type="hidden" name="visitors_id" value="<?php echo $visitors_id; ?>">
		    <input type="text" name="visitors_card" value="<?php echo $visitors_card; ?>">
		    <br>
		    First name:<br>
		    <input type="text" name="fname" value="<?php echo $fname; ?>">
		    <br>
		    Last name:<br>
		    <input type="text" name="lname" value="<?php echo $lname; ?>">
		    <br>
		    Email:<br>
		    <input type="text" name="address" value="<?php echo $address; ?>">
		    <br>
		    Password:<br>
		    <input type="text" name="contact_no" value="<?php echo $contact_no; ?>">
		    <br>
		    Gender:<br>
		    <input type="radio" name="category" value="Teacher" <?php if($category == 'Teacher'){ echo "checked";} ?>>Teacher
		    <input type="radio" name="category" value="Student" <?php if($category == 'Student'){ echo "checked";} ?>>Student
		    <input type="radio" name="category" value="Visitor" <?php if($category == 'Visitor'){ echo "checked";} ?>>Visitor
		    <br><br>
		    <input type="submit" value="Update" name="update">
		  </fieldset>
		</form>

		</body>
		</html>




	<?php
	} else{
		// If the 'id' value is not valid, redirect the user back to view.php page
		header('Location: view.php');
	}

}
?>